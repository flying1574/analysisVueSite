<template>
  <div id="app">
    <AnalysisForm></AnalysisForm>
  </div>
</template>

<script>
import AnalysisForm from "./components/AnalysisForm.vue";

export default {
  name: "App",
  components: {
    AnalysisForm,
  },
};
</script>

<style>
#app {
  text-align: center;
  width: 1200px;
  margin: 0 auto;
  font-family: "Gill Sans", "Gill Sans MT", Calibri, "Trebuchet MS", sans-serif;
  color: #383838;
  background: rgb(252, 251, 251);
}
</style>

import service from "@/request/index";

// 单句分析接口
export function awsInputApi(data) {
    return service({
        url: "https://uahbbdnxfuyenmm6i5pvo5tsri0caflb.lambda-url.us-east-1.on.aws/",
        method: "POST",
        data
    })
}
export function tXInputApi(data) {
    return service({
        url: "https://service-05tvadnp-1258281300.sh.apigw.tencentcs.com/release/helloworld-1659064292",
        method: "POST",
        data
    })
}
export function aLiInputApi(data) {
    return service({
        url: "https://393c459391d74d91b9b699474e4e2fb1-cn-shanghai.alicloudapi.com/",
        method: "POST",
        data
    })
}
import axios from "axios";

//创建axios实例
const service = axios.create({
    baseURL: "",
    // baseURL: "https://wsw4sfshka7b2j4v7z5rylspti0dxdcd.lambda-url.us-east-1.on.aws",
    timeout: 5000,
    headers: {
        "Content-type": "application/json;charset=utf-8"
    }
})

//请求拦截
service.interceptors.request.use((config) => {
    config.headers = config.headers || {}
    if (localStorage.getItem("token")) {
        config.headers.token = localStorage.getItem("token") || ""
    }
    return config
})

//响应拦截
service.interceptors.response.use((res) => {
    const code = res.status
    // console.log(code);
    if (code != 200) {
        return Promise.reject(res.data)
    }
    return res.data
}, (err) => {
    console.log(err)
})

export default service
<template>
  <div>
    <h1>情绪分析系统</h1>
    <h3>请按一下说明执行操作</h3>
    <h2>单句分析</h2>

    <!-- aws -->
    <el-form :model="awsFormData" ref="awsFormData">
      <div class="flex-display">
        <el-form-item>
          <el-button
            @click="aInput('awsFormData')"
            type="primary"
            style="margin-right: 30px"
            >开始单句分析</el-button
          >
        </el-form-item>

        <div class="input">
          <el-form-item prop="aInputData">
            <el-input
              style="width: 300px"
              v-model="awsFormData.aInputData"
              placeholder="请输入要分析的语句"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">正向概率：</div>
        <div class="input">
          <el-form-item prop="Positive">
            <el-input
              disabled
              style="width: 100px"
              v-model="awsFormData.Positive"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">负向概率：</div>
        <div class="input">
          <el-form-item prop="Negative">
            <el-input
              disabled
              style="width: 100px"
              v-model="awsFormData.Negative"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">中性判断：</div>

        <div class="input">
          <el-form-item prop="Neutral">
            <el-input
              disabled
              style="width: 100px"
              v-model="awsFormData.Neutral"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>
      </div>
    </el-form>

    <!-- tx -->
    <el-form :model="txFormData" ref="txFormData">
      <div class="flex-display">
        <el-form-item>
          <el-button
            @click="txInput('txFormData')"
            type="primary"
            style="margin-right: 30px"
            >开始单句分析</el-button
          >
        </el-form-item>

        <div class="input">
          <el-form-item prop="txInputData">
            <el-input
              style="width: 300px"
              v-model="txFormData.txInputData"
              placeholder="请输入要分析的语句"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">正向概率：</div>
        <div class="input">
          <el-form-item prop="Positive">
            <el-input
              disabled
              style="width: 100px"
              v-model="txFormData.Positive"
              placeholder="输出内容"
              >23</el-input
            >
          </el-form-item>
        </div>

        <div class="left-box">负向概率：</div>
        <div class="input">
          <el-form-item prop="Negative">
            <el-input
              disabled
              style="width: 100px"
              v-model="txFormData.Negative"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">中性判断：</div>

        <div class="input">
          <el-form-item prop="Neutral">
            <el-input
              disabled
              style="width: 100px"
              v-model="txFormData.Neutral"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>
      </div>
    </el-form>

    <!-- ali -->
    <el-form :model="aLiFormData" ref="aLiFormData">
      <div class="flex-display">
        <el-form-item>
          <el-button
            @click="aLiInput('aLiFormData')"
            type="primary"
            style="margin-right: 30px"
            >开始单句分析</el-button
          >
        </el-form-item>

        <div class="input">
          <el-form-item prop="aLiInputData">
            <el-input
              style="width: 300px"
              v-model="aLiFormData.aLiInputData"
              placeholder="请输入要分析的语句"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">正向概率：</div>
        <div class="input">
          <el-form-item prop="Positive">
            <el-input
              disabled
              style="width: 100px"
              v-model="aLiFormData.positive_prob"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">负向概率：</div>
        <div class="input">
          <el-form-item prop="Negative">
            <el-input
              disabled
              style="width: 100px"
              v-model="aLiFormData.negative_prob"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>

        <div class="left-box">中性判断：</div>

        <div class="input">
          <el-form-item prop="Neutral">
            <el-input
              disabled
              style="width: 100px"
              v-model="aLiFormData.neutral_prob"
              placeholder="输出内容"
            ></el-input>
          </el-form-item>
        </div>
      </div>
    </el-form>
  </div>
</template>
<script>
import Vue from "vue";
import ElementUI from "element-ui";
import { awsInputApi, tXInputApi, aLiInputApi } from "../request/api";
import axios from "axios";

Vue.use(ElementUI);
export default {
  data() {
    return {
      awsFormData: {
        aInputData: "",
        Positive: "",
        Negative: "",
        Neutral: "",
      },
      txFormData: {
        txInputData: "",
        Positive: "",
        Negative: "",
        Neutral: "",
      },
      aLiFormData: {
        aLiInputData: "",
        positive_prob: "",
        negative_prob: "",
        neutral_prob: "",
      },
    };
  },
  methods: {
    aInput(formName) {
      // debugger
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const data = this.awsFormData.aInputData;
          axios({
            method: "post",
            url: "https://uahbbdnxfuyenmm6i5pvo5tsri0caflb.lambda-url.us-east-1.on.aws",
            data,
          }).then((res) => {
            console.log(res);
          });
          // console.log(data);
          // awsInputApi(data).then((res) => {
          //   // const { Mixed, Negative, Neutral, Positive } = res.SentimentScore;
          //   console.log(res);
          //   // this.awsFormData = { ...res.SentimentScore };
          // });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    txInput(formName) {
      // debugger
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const data = this.txFormData.txInputData;
          tXInputApi(data).then((res) => {
            // const { Mixed, Negative, Neutral, Positive } = res.SentimentScore;
            console.log(res);
            this.txFormData = { ...res };
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    aLiInput(formName) {
      // debugger
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const data = this.aLiFormData.aLiInputData;
          aLiInputApi(data).then((res) => {
            // const { Mixed, Negative, Neutral, Positive } = res.SentimentScore;
            console.log(res);
            this.aLiFormData = { ...res };
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.input {
  margin-right: 30px;
}
.upload-demo {
  width: 100%;
}
.flex-display {
  margin: 50px 30px;
  width: 100%;
  display: flex;
  align-items: flex-start;

  .left-box {
    margin: 20 30;
    height: 36px;
    line-height: 36px;
  }
  .sub-title {
  }
}
.el-upload {
  margin-left: 40px;
  .el-btn {
    font-size: 16px;
  }
  .el-upload-tip {
    display: inline;
    font-size: 12px;
  }
}

input #file-upload-button {
  background-color: #409eff;
}
</style>
